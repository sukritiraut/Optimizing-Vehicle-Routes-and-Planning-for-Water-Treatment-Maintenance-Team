# app.py
from flask import Flask, render_template, jsonify, request
from werkzeug.utils import secure_filename
import itertools
import time
import random
import math
import requests
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from utils.kmeans3 import k_means_clustering
from utils.genetic_single import genetic_algorithm

app = Flask(__name__)

def get_distance_matrix(points):
    try:
        full=''
        for l in points:
            full+=f'{l["lng"]},{l["lat"]};'
        url = f'http://34.201.241.242:5000/table/v1/driving/'+full[:-1]+'?annotations=distance,duration'
        #print(url)

        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()
            return data['durations'],data['distances']
        else:
            [],[]
    except Exception as err:
        print(err)
        return None
    
def path_distance(distance_matrix, path):
    """
    Calculate the total distance of a given path using the provided distance matrix.

    Parameters:
    - distance_matrix: 2D list of distances between cities (distance matrix)
    - path: List of cities representing the path

    Returns:
    - Total distance of the path
    """
    if len(path)<2:return 0 
    return sum(distance_matrix[path[i-1]][path[i]] for i in range(1, len(path))) + distance_matrix[path[-1]][path[0]]


##########################

##########################
def tsp_bruteforce(dist_matrix):
    """Return the indices of points in the shortest round trip order using a precomputed distance matrix."""

    min_path_indices = None
    min_distance = float('inf')
    n=len(dist_matrix)
    # Start from the first point and compute permutations for the rest of the points
    for perm in itertools.permutations(range(1, n), n - 1):
        path_indices = [0] + list(perm) + [0]  # Start and end at the home point
        current_distance = sum(dist_matrix[path_indices[i]][path_indices[i+1]] for i in range(n))

        if current_distance < min_distance:
            min_distance = current_distance
            min_path_indices = path_indices

    return min_path_indices
##########################

##########################
def nearest_neighbor_single(distance_matrix):
    num_cities = len(distance_matrix)
    unvisited = set(range(1, num_cities))  # Since we're starting from the first city
    
    current_city = 0  # Start from the first city
    tour = [current_city]
    
    while unvisited:
        next_city = min(unvisited, key=lambda city: distance_matrix[current_city][city])
        tour.append(next_city)
        current_city = next_city
        unvisited.remove(next_city)
        
    tour.append(tour[0])  # Return to the starting city
    return tour
##########################

##########################
def simulated_annealing(distance_matrix, start_temp, end_temp, cooling_rate):
    num_cities = len(distance_matrix)
    
    if num_cities == 2:return [0,1,0]
    # Generate an initial tour that starts with the first city
    tour = list(range(num_cities))
    
    # Function to compute the total distance of a tour
    def get_tour_distance(tour):
        return sum(distance_matrix[tour[i]][tour[i + 1]] for i in range(num_cities - 1)) + distance_matrix[tour[-1]][tour[0]]

    current_distance = get_tour_distance(tour)
    temp = start_temp

    while temp > end_temp:
        new_tour = tour.copy()
        
        # Swap two random cities to get a neighboring solution, excluding the first city
        a, b = random.sample(range(1, num_cities), 2)
        new_tour[a], new_tour[b] = new_tour[b], new_tour[a]
        
        new_distance = get_tour_distance(new_tour)
        
        # If the new tour is shorter or the temperature is high enough to accept a longer tour
        if new_distance < current_distance or random.random() < math.exp((current_distance - new_distance) / temp):
            tour, current_distance = new_tour, new_distance
        
        temp *= cooling_rate

    tour.append(tour[0])  # Return to the starting city
    return tour
##########################

##########################
def mtsp_dynamic_programming(total_distances, num_salesmen):
    num_cities = len(total_distances)

    # Helper function to compute TSP for a set of cities starting and ending at a base (home) city
    def compute_tsp(base, cities):
        min_path = None
        min_cost = float('inf')
        for path in itertools.permutations(cities):
            cost = total_distances[base][path[0]] + sum(total_distances[path[i]][path[i + 1]] for i in range(len(path) - 1)) + total_distances[path[-1]][base]
            if cost < min_cost:
                min_cost = cost
                min_path = [base] + list(path) + [base]
        return min_cost, min_path

    # Divide the cities among the salesmen, excluding the home city
    cities_per_salesman = (num_cities - 1) // num_salesmen
    remaining_cities = (num_cities - 1) % num_salesmen

    all_paths = []
    total_cost = 0
    start = 1

    for _ in range(num_salesmen):
        end = start + cities_per_salesman
        if remaining_cities > 0:
            end += 1
            remaining_cities -= 1

        # Assign cities to salesman and compute TSP
        cities_assigned = list(range(start, end))
        cost, path = compute_tsp(0, cities_assigned)
        all_paths.append(path)
        total_cost += cost

        start = end

    return total_cost, all_paths
##########################

def kmeans_brute_force(total_distances, num_salesmen):
    ans=[]
    
    #clusters = k_means_distance_matrix(total_distances, num_salesmen)
    clusters= k_means_clustering(total_distances, m=num_salesmen, max_iterations=500)
    
    for cluster in clusters:
        sub_mat=[[total_distances[i][j] for j in cluster] for i in cluster]

        min_dist, order = tsp_memo(sub_mat, 0, 1, {})
        ans.append([cluster[i] for i in order])
    return ans
##########################

def kmeans_nneighbor(total_distances, num_salesmen):
    ans=[]
    
    #clusters = k_means_distance_matrix(total_distances, num_salesmen)
    clusters= k_means_clustering(total_distances, m=num_salesmen, max_iterations=500)

    for cluster in clusters:
        sub_mat=[[total_distances[i][j] for j in cluster] for i in cluster]
        order=nearest_neighbor_single(sub_mat)
        ans.append([cluster[i] for i in order])
    return ans


##########################
def genetic_mutli(total_distances,num_salesmen):
    ans=[]
    l=len(total_distances)-1
    optimal_visit= l//num_salesmen

    while True:
        try:
            clusters= k_means_clustering(total_distances, m=num_salesmen, max_iterations=500)
            print(clusters)
            all_clusters_valid=all(abs(len(cluster)-optimal_visit)<=2 for cluster in clusters)
            if all_clusters_valid:
                break  # Clusters meet the desired condition
        except:
            pass
            
    try:
        for cluster in clusters:
            sub_mat=[[total_distances[i][j] for j in cluster] for i in cluster]
            order, best_distance = genetic_algorithm(sub_mat)
            ans.append([cluster[i] for i in order])
    except Exception as err:
        print(err)
    return ans
##########################
def tsp_memo(distances, current_city, visited, memo):
    # Base case: if all cities have been visited, return distance to the starting city and the starting city itself
    if visited == (1 << len(distances)) - 1:
        return distances[current_city][0], [current_city, 0]

    # If we've already calculated this path, return the cached value
    if (current_city, visited) in memo:
        return memo[(current_city, visited)]

    min_distance = float('inf')
    min_path = []

    # Iterate through all cities
    for next_city in range(len(distances)):
        # If this city hasn't been visited yet
        if not visited & (1 << next_city):
            distance, path = tsp_memo(distances, next_city, visited | (1 << next_city), memo)
            distance += distances[current_city][next_city]
            
            if distance < min_distance:
                min_distance = distance
                min_path = [current_city] + path

    # Cache the result and return
    memo[(current_city, visited)] = (min_distance, min_path)
    return min_distance, min_path
##########################

def google_tsp_multi(data):
    """Entry point of the program."""
    # Instantiate the data problem.
    manager = pywrapcp.RoutingIndexManager(
        len(data["distance_matrix"]), data["num_vehicles"], data["depot"]
    )

    # Create Routing Model.
    routing = pywrapcp.RoutingModel(manager)


    def distance_callback(from_index, to_index):
        """Returns the distance between the two nodes."""
        # Convert from routing variable Index to distance matrix NodeIndex.
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data["distance_matrix"][from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)

    # Define cost of each arc.
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

        # Add Distance constraint.
    dimension_name = "Distance"
    routing.AddDimension(
        transit_callback_index,
        0,  # no slack
        30000000,  # vehicle maximum travel distance
        True,  # start cumul to zero
        dimension_name,
    )
    distance_dimension = routing.GetDimensionOrDie(dimension_name)
    distance_dimension.SetGlobalSpanCostCoefficient(100000)

    # Setting first solution heuristic.
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    )

    # Solve the problem.
    solution = routing.SolveWithParameters(search_parameters)

    # Print solution on console.
    # [START print_solution]
    if solution:
        r=get_routes(solution=solution,routing=routing,manager=manager)
        #print_solution(data=data,solution=solution,routing=routing,manager=manager)
        #print(r)
        return r
    else:
        print("No solution found !")
    # [END print_solution]

def get_routes(solution, routing, manager):
  """Get vehicle routes from a solution and store them in an array."""
  # Get vehicle routes and store them in a two dimensional array whose
  # i,j entry is the jth location visited by vehicle i along its route.
  routes = []
  distances=[]
  for route_nbr in range(routing.vehicles()):
    index = routing.Start(route_nbr)
    route = [manager.IndexToNode(index)]
    route_distance = 0
    while not routing.IsEnd(index):
      index = solution.Value(routing.NextVar(index))
      route.append(manager.IndexToNode(index))
    routes.append(route)
  return routes

def print_solution(data, manager, routing, solution):
    """Prints solution on console."""
    #print(f"Objective: {solution.ObjectiveValue()}")
    max_route_distance = 0
    for vehicle_id in range(data["num_vehicles"]):
        index = routing.Start(vehicle_id)
        plan_output = f"Route for vehicle {vehicle_id}:\n"
        route_distance = 0
        while not routing.IsEnd(index):
            plan_output += f" {manager.IndexToNode(index)} -> "
            previous_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(
                previous_index, index, vehicle_id
            )
        plan_output += f"{manager.IndexToNode(index)}\n"
        plan_output += f"Distance of the route: {route_distance}m\n"
        print(plan_output)
        max_route_distance = max(route_distance, max_route_distance)
    #print(f"Maximum of the route distances: {max_route_distance}m")

def calculate_total_distance(distance_matrix, routes):
    total_distances = []
    for route in routes:
        total_distance = 0
        for i in range(len(route) - 1):
            total_distance += distance_matrix[route[i]][route[i + 1]]
        total_distances.append(total_distance)
    return total_distances

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data_post = request.get_json()
    numberofvehicles=data_post.get('numofvehicles')
    markers=data_post.get('markers')
    #print(markers)
    selected_algo_index=data_post.get('which_algo')
    #print(data_post)
    # Use the data to calculate distance matrix and solve the TSP
    if(len(markers)<2):return []
    if numberofvehicles > len(markers)-1:
        numberofvehicles = len(markers)-1

    t1=time.time()
    dur_matrix, dist_matrix=get_distance_matrix(points=markers)
    dist_matrix = [[round(num) for num in inner] for inner in dist_matrix]
    t2=time.time()
    
    data = {}
    data["distance_matrix"] = dist_matrix
    data["num_vehicles"] = numberofvehicles
    data["depot"] = 0
    ##print(data)
    t3=time.time()
    if selected_algo_index==1:
        #print('Modified brute-force')
        min_dist, order = tsp_memo(dist_matrix, 0, 1, {})
        ans=[order]
    elif selected_algo_index==2:
        order=nearest_neighbor_single(dist_matrix)
        ans=[order]
    elif selected_algo_index==3:
        order=simulated_annealing(dist_matrix,1000,1,cooling_rate=0.995)
        ans=[order]
    elif selected_algo_index==4:
        ans=google_tsp_multi(data)
    elif selected_algo_index==5:
        total_cost, ans=mtsp_dynamic_programming(dist_matrix,numberofvehicles)
    elif selected_algo_index==6:
        ans=kmeans_brute_force(dist_matrix,numberofvehicles)
    elif selected_algo_index==7:
        ans=kmeans_nneighbor(dist_matrix,numberofvehicles)
    elif selected_algo_index==8:
        best_route, best_distance = genetic_algorithm(dist_matrix)
        ans=[best_route]
    elif selected_algo_index==9:
        ans = genetic_mutli(dist_matrix,numberofvehicles)
        #best_route = genetic_algorithm(dist_matrix, pop_size=100, generations=500, mutation_rate=0.1)

    dist_list=calculate_total_distance(dist_matrix,ans)
    t4=time.time()
 

    return jsonify({
        'distance_matrix':[dist_matrix],
        'distance':dist_list,
        'ans': ans,
        'algo_calculation_time':round(t4-t3,2),
        'total_calculation_time':round(t4-t1,2)
    })

if __name__ == "__main__":
    app.run(debug=True,port=8888)