import random

def euclidean_distance(point1, point2):
    # Calculate the Euclidean distance between two points
    return sum((x - y) ** 2 for x, y in zip(point1, point2)) ** 0.5

def k_means_clustering(distance_matrixf, m, max_iterations):
    distance_matrix = [row[1:] for row in distance_matrixf[1:]]
    n = len(distance_matrix)
    
    # Step 1: Initialize cluster centroids (randomly or using k-means++)
    centroids = random.sample(range(n), m)  # Random initialization
    
    for _ in range(max_iterations):
        # Step 2: Assign each location to the nearest centroid
        cluster_assignments = []
        for i in range(n):
            distances_to_centroids = [distance_matrix[i][centroid] for centroid in centroids]
            closest_cluster = min(range(m), key=lambda x: distances_to_centroids[x])
            cluster_assignments.append(closest_cluster)
        
        # Step 3: Update cluster centroids
        new_centroids = []
        for cluster in range(m):
            cluster_indices = [i for i, assignment in enumerate(cluster_assignments) if assignment == cluster]
            cluster_mean = [sum(distance_matrix[i][j] for i in cluster_indices) / len(cluster_indices) for j in range(n)]
            new_centroids.append(min(range(n), key=lambda x: cluster_mean[x]))
        
        # Check for convergence
        if centroids == new_centroids:
            break
        
        centroids = new_centroids
    
    # Create a list of clustered locations
    clustered_locations = [[] for _ in range(m)]
    for i, cluster_index in enumerate(cluster_assignments):
        clustered_locations[cluster_index].append(i)
    

    cluster_list=[]
    for cluster in clustered_locations:
        s=[0]
        s.extend([i+1 for i in cluster])
        cluster_list.append(s)

    return cluster_list

# Example usage:
# cluster_assignments = k_means_clustering(distance_matrix, m=3, max_iterations=100)
