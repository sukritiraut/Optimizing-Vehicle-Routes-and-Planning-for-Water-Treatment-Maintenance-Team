import random

def create_individual(n):
    individual = list(range(1, n))
    random.shuffle(individual)
    return [0] + individual + [0]

def compute_fitness(individual, distance_matrix):
    distance = 0
    for i in range(len(individual) - 1):
        distance += distance_matrix[individual[i]][individual[i + 1]]
    return distance

def select(population, fitnesses, num_parents):
    sorted_population = [x for _, x in sorted(zip(fitnesses, population))]
    return sorted_population[:num_parents]

def crossover(parent1, parent2):
    child = [-1] * len(parent1)
    child[0] = child[-1] = 0  # Start and end at the home location
    start, end = sorted(random.sample(range(1, len(parent1) - 1), 2))
    child[start:end] = parent1[start:end]

    for i in range(1, len(parent2) - 1):
        if parent2[i] not in child:
            for j in range(1, len(child) - 1):
                if child[j] == -1:
                    child[j] = parent2[i]
                    break
    return child

def mutate(individual, mutation_rate):
    for i in range(1, len(individual) - 1):
        if random.random() < mutation_rate:
            j = random.randint(1, len(individual) - 2)
            individual[i], individual[j] = individual[j], individual[i]
    return individual

def genetic_algorithm(distance_matrix, population_size=100, num_generations=1000, mutation_rate=0.01):
    num_cities = len(distance_matrix)
    if num_cities<3:return [0,1,0],distance_matrix[0][1]+distance_matrix[1][0]
    population = [create_individual(num_cities) for _ in range(population_size)]

    for _ in range(num_generations):
        fitnesses = [compute_fitness(individual, distance_matrix) for individual in population]
        parents = select(population, fitnesses, population_size // 2)
        next_population = parents.copy()

        while len(next_population) < population_size:
            parent1, parent2 = random.sample(parents, 2)
            child = crossover(parent1, parent2)
            next_population.append(mutate(child, mutation_rate))

        population = next_population

    best_individual = select(population, fitnesses, 1)[0]
    return best_individual, compute_fitness(best_individual, distance_matrix)