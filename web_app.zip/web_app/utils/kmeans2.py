import random

def find_new_centroid(cluster, distance_matrix):
    """Finds the new centroid for a cluster based on the distance matrix."""
    if not cluster:
        return None
    min_distance_sum = float('inf')
    centroid = None
    for i in cluster:
        distance_sum = sum(distance_matrix[i][j] for j in cluster)
        if distance_sum < min_distance_sum:
            min_distance_sum = distance_sum
            centroid = i
    return centroid

def assign_to_clusters(centroids, distance_matrix):
    """Assigns each point to the closest centroid based on the distance matrix."""
    clusters = {centroid: [] for centroid in centroids}
    for i, row in enumerate(distance_matrix):
        closest_centroid = min(centroids, key=lambda centroid: distance_matrix[i][centroid])
        clusters[closest_centroid].append(i)
    return clusters

def k_means_distance_matrix2(distance_matrixf, m):
    """Clusters points into m sub-lists based on the distance matrix."""
    distance_matrix = [row[1:] for row in distance_matrixf[1:]]
    n = len(distance_matrix)
    centroids = random.sample(range(n), m)
    previous_clusters = None

    while True:
        clusters = assign_to_clusters(centroids, distance_matrix)
        new_centroids = [find_new_centroid(cluster, distance_matrix) for cluster in clusters.values()]

        if new_centroids == centroids:
            break

        centroids = new_centroids

    cluster_list=[]
    for cluster in list(clusters.values()):
        s=[0]
        s.extend([i+1 for i in cluster])
        cluster_list.append(s)
    return cluster_list

# Example usage:
n = 10  # Size of the distance matrix
m = 3   # Number of clusters


# Example usage:
distance_matrix=[
        [ 0, 48, 65, 68, 68, 10, 84, 22, 37, 88, 71, 89],
        [48,  0, 59, 66, 40, 88, 47, 89, 82, 38, 26, 78],
        [65, 59,  0, 81, 70, 80, 48, 65, 83, 89, 50, 30],
        [68, 66, 81,  0, 33, 66, 10, 58, 33, 32, 75, 24],
        [68, 40, 70, 33,  0,  1,  1, 37, 54,  6, 39, 18],
        [10, 88, 80, 66,  1,  0, 66, 42, 58, 36, 12, 47],
        [84, 47, 48, 10,  1, 66,  0, 85, 76, 69,  7, 69],
        [22, 89, 65, 58, 37, 42, 85,  0, 24, 80, 14, 86],
        [37, 82, 83, 33, 54, 58, 76, 24,  0,  1, 51, 37],
        [88, 38, 89, 32,  6, 36, 69, 80,  1,  0, 11, 44],
        [71, 26, 50, 75, 39, 12,  7, 14, 51, 11,  0, 21],
        [89, 78, 30, 24, 18, 47, 69, 86, 37, 44, 21,  0]]

m = 4  # Number of cars

clusters = k_means_distance_matrix2(distance_matrix, m)
