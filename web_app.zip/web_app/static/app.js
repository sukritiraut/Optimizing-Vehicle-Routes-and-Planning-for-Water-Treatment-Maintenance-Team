let map;
let edgeGroup;
let pinGroup;
let legendGroup;
let markers=[];
let homeMarker = null;
let contextMenu;
let currentMarker = null;

document.addEventListener("DOMContentLoaded", function () {
    map = L.map('map').setView([34, -83], 12);
    map.doubleClickZoom.disable();
    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {}).addTo(map);
    pinGroup = L.layerGroup().addTo(map);
    edgeGroup = L.layerGroup().addTo(map);
    legendGroup = L.layerGroup().addTo(map);
    contextMenu = document.getElementById('contextMenu');
    
    loadFromLocalStorage();
    map.on('contextmenu', function(e) {
        e.originalEvent.preventDefault();
        // your other code to handle right-click on the map...
    });


    map.on('dblclick', function (e) {
        var marker = L.marker(e.latlng).addTo(pinGroup);
        addMarker(marker);
        attachRightClickEventToMarker(marker);
    });

    document.getElementById('deleteMarker').onclick = function (e) {
        if (currentMarker) {
            const index = markers.indexOf(currentMarker);
            if (index > -1) {
                markers.splice(index, 1);
            }
            if (homeMarker === currentMarker) {
                homeMarker = markers[0];
                homeMarker.setIcon(new L.Icon({
                    iconUrl: '/static/home.png',
                    iconSize: [41, 41],
                    iconAnchor: [20, 41]
                }));
            }
            map.removeLayer(currentMarker);
            updateMarkerList();
            contextMenu.style.display = 'none';
            saveToLocalStorage();
        }
    };

    document.getElementById('markHome').onclick = function () {
        if (currentMarker) {
            if (homeMarker) {
                homeMarker.setIcon(new L.Icon.Default());
            }
            currentMarker.setIcon(new L.Icon({
                iconUrl: '/static/home.png',
                iconSize: [41, 41],
                iconAnchor: [20, 41]
            }));
            const index = markers.indexOf(currentMarker);
            if (index > -1) {
                markers.splice(index, 1);
            }
            markers.unshift(currentMarker);
            homeMarker = currentMarker;
            updateMarkerList();
            contextMenu.style.display = 'none';
            saveToLocalStorage();
        }
    };

    document.addEventListener('click', function (e) {
        if (e.target.closest('#contextMenu') !== contextMenu) {
            contextMenu.style.display = 'none';
        }
    });
});

function attachRightClickEventToMarker(marker) {
    marker.on('contextmenu', function (event) {
        currentMarker = marker;
        var contextMenu = document.getElementById('contextMenu');
        contextMenu.style.left = event.originalEvent.pageX + 'px';
        contextMenu.style.top = event.originalEvent.pageY + 'px';
        contextMenu.style.display = 'block';
    });
}

function addMarker(marker) {
    if(markers.length==0){
        marker.setIcon(new L.Icon({
            iconUrl: '/static/home.png',
            iconSize: [41, 41],
            iconAnchor: [20, 41]
        }));
    }
    markers.push(marker);
    updateMarkerList();
    saveToLocalStorage();
}

function updateMarkerList() {
    const list = document.getElementById('marker-list');
    list.innerHTML = '';
    markers.forEach((marker, index) => {
        const latLng = marker.getLatLng();

        const item = document.createElement('li');
        item.classList.add("list-group-item");
        
        // Displaying latitude and longitude along with the marker's number
        const markerText = document.createElement('span');
        markerText.innerText = `(${latLng.lat.toFixed(3)}, ${latLng.lng.toFixed(3)})`;
        
        const removeButton = document.createElement('button');
        removeButton.innerText = 'Remove';
        removeButton.classList.add('btn', 'btn-danger', 'btn-sm', 'float-right');  // Bootstrap classes
        removeButton.onclick = function (e) {
            e.stopPropagation(); // Prevent firing the parent's click event
            map.removeLayer(marker);
            const idx = markers.indexOf(marker);
            if (idx > -1) {
                markers.splice(idx, 1);
            }
            if (homeMarker === marker) {
                homeMarker = null;
            }
            updateMarkerList();
            saveToLocalStorage();
        };

        item.onclick = function () {
            map.setView(marker.getLatLng(), 13);
        };
        
        item.appendChild(markerText);
        item.appendChild(removeButton);
        list.appendChild(item);
    });
}


function saveToLocalStorage() {
    const data = markers.map(m => m.getLatLng());
    const homeIndex = markers.indexOf(homeMarker);
    localStorage.setItem('markers', JSON.stringify(data));
    localStorage.setItem('home', homeIndex);
}

function loadFromLocalStorage() {
    const data = JSON.parse(localStorage.getItem('markers') || "[]");
    const homeIndex = parseInt(localStorage.getItem('home'));

    data.forEach((latlng, index) => {
        const marker = L.marker(latlng).addTo(pinGroup);
        attachRightClickEventToMarker(marker);
        markers.push(marker);

        if (index === 0) {
            marker.setIcon(new L.Icon({
                iconUrl: '/static/home.png',
                iconSize: [41, 41],
                iconAnchor: [20, 41]
            }));
            map.setView(marker.getLatLng(), 9);
            homeMarker = marker;
        }
    });
    updateMarkerList();
}

document.getElementById('algo').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex].text.toLowerCase();
    var numoftracksInput = document.getElementById('numoftracks');

    if (selectedOption.includes('single')) {
        numoftracksInput.disabled = true;
        numoftracksInput.value = 1;
    } else if (selectedOption.includes('multi')) {
        numoftracksInput.disabled = false;
    }
});

document.getElementById("calculate").addEventListener("click", function() {
    const buttonCal = this;
    var selectElement = document.getElementById('algo');
    var algo_name = selectElement.options[selectElement.selectedIndex].text;
    var numofvehicles = document.getElementById('numoftracks').value;
    edgeGroup.clearLayers();
    if (markers.length>=2){
        // Show spinner and disable button
        buttonCal.disabled = true;
        buttonCal.querySelector('.spinner-border').style.display = 'inline-block';
        var postData = {
            markers: markers.map(m => m.getLatLng()),
            numofvehicles: parseInt(numofvehicles, 10), // Convert the count value to an integer
            which_algo : parseInt(selectElement.value,10)
        };
        fetch('/calculate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postData)
        })
        .then(response => response.json())
        .then(incoming => {
            const routes = incoming['ans'];
            const distance_list=incoming['distance'];
            const calc_time = incoming['total_calculation_time']
            console.log(incoming);
            appendRoutes(routes,calc_time,markers,algo_name,distance_list);
            document.querySelectorAll('.route-legend').forEach(el => el.remove());
            routes.forEach((route, index) => {
                // Define a color for this route, you can customize this part to pick a color
                const routeColor = `hsl(${(index * 60) % 360}, 100%, 50%)`;
        
                // Add the legend for this route
                const legend = L.control({ position: 'bottomright' });
                legend.onAdd = function (map) {
                    const div = L.DomUtil.create('div', 'info legend route-legend');
                    div.style.backgroundColor = 'white';
                    div.style.padding = '6px';
                    div.style.margin = '2px';
                    div.style.border = '1px solid #ddd';
                    div.innerHTML = `
                        <i style="background: ${routeColor}; width: 18px; height: 18px; float: left; margin-right: 8px; opacity: 0.7;"></i>
                        <span>Vehicle ${index + 1}-> ${(distance_list[index]/1609).toFixed(1)} mile</span>
                    `;
                    return div;
                };
                legend.addTo(map);


                // Iterate over each pair of points in the route
                for (var i = 0; i < route.length - 1; i++) {
                    let point1 = markers[route[i]].getLatLng();
                    
                    let point2 = markers[route[i + 1]].getLatLng();
                    let edge = L.polyline([point1, point2], { color: routeColor }).addTo(edgeGroup);
                    
                    const decorator = L.polylineDecorator(edge, {
                        patterns: [
                            // You can customize the pattern as needed
                            {
                                offset: '25%', 
                                repeat: '30%', 
                                symbol: L.Symbol.arrowHead({
                                    pixelSize: 10,
                                    polygon: false,
                                    pathOptions: { stroke: true, color: routeColor }
                                })
                            }
                        ]
                    }).addTo(edgeGroup);

                }
            });

        }).finally(() => {
            buttonCal.disabled = false;
            buttonCal.querySelector('.spinner-border').style.display = 'none';
        });
    }else{alert("At least 2 points need to be selected on the map.")}
});

function processCSV(csvText) {
    var lines = csvText.split("\n");
    var headers = lines[0].replace(/(\r\n|\n|\r)/gm, "").split(",");
    let coordinates =[];
    console.log(headers);

    // Column names
    var column1Name = "lat"; 
    var column2Name = "lng";

    // Find the index of the columns
    var latIndex = headers.indexOf(column1Name);
    var lngIndex = headers.indexOf(column2Name);

    if(latIndex === -1 || lngIndex === -1) {
        alert("Columns 'lat' and 'lng' could not be found in the csv file.");
        return;
    }
    for (var i = 1; i < lines.length; i++) {
        const lineSplitted = lines[i].split(",");
        const latf=parseFloat(lineSplitted[latIndex]);
        const lngf=parseFloat(lineSplitted[lngIndex]);
        if(!isNaN(latf) && !isNaN(lngf)){
            coordinates.push([latf, lngf]);
        }
    }

    // Add markers to the map
    loadbulk(coordinates)
}

function loadbulk(data) {

    data.forEach((latlng, index) => {
        const marker = L.marker(latlng).addTo(pinGroup);
        attachRightClickEventToMarker(marker);
        markers.push(marker);

        if (index === 0 && homeMarker===null) {
            marker.setIcon(new L.Icon({
                iconUrl: '/static/home.png',
                iconSize: [41, 41],
                iconAnchor: [20, 41]
            }));
            map.setView(marker.getLatLng(), 9);
            homeMarker = marker;
        }
    });
    updateMarkerList();
    saveToLocalStorage();
}


function handleFileSelect(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(event) {
        const text = event.target.result;
        processCSV(text);
    };

    reader.readAsText(file);
}

function appendRoutes(routes,calc_time,markers,algo_name,distance_list) {
    const container = document.getElementById('accordion');
    var baseUrl = 'https://www.google.com/maps/dir/';
    // Create the card structure
    const card = document.createElement('div');
    card.className = 'card my-1';

    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header';
    cardHeader.textContent = `Route Details: Points: ${markers.length} | Algorithm: ${algo_name} | Total Distance:${((distance_list.reduce((accumulator, currentValue) => accumulator + currentValue, 0))/1609).toFixed(1)} | Calculation Time: ${calc_time}s`;

    const cardBody = document.createElement('div');
    cardBody.className = 'card-body';

    // Iterate through each route in the routes array
    routes.forEach((route, index) => {
        // Add route information
        let routeInfo = document.createElement('p');
        //let routeInfo2 = document.createElement('p');
        routeInfo.textContent = route.join(" -> "); // Assuming route is an array of strings
        //routeInfo2.textContent = route.map(index => markers[index].getLatLng()).join(" -> ");
        var url = route.map(index =>{
            var latLng = markers[index].getLatLng();
            return latLng.lat + ',' + latLng.lng;
        }).join('/');
        var fullUrl = baseUrl + url;
        let glink = document.createElement('a');
        glink.href = fullUrl;
        glink.textContent = 'Open in Google Maps';
        glink.target = '_blank'; // Open in a new window/tab
        cardBody.appendChild(routeInfo);
        cardBody.appendChild(glink);

        // Add a horizontal separator, except after the last route
        if (index < routes.length - 1) {
            let separator = document.createElement('hr');
            cardBody.appendChild(separator);
        }
    });

    // Append the card header and body to the card
    card.appendChild(cardHeader);
    card.appendChild(cardBody);

    // Append the card to the container
    container.insertBefore(card, container.firstChild);
   
}

function deleteAllPins(){
    edgeGroup.clearLayers();
    pinGroup.clearLayers();
    const marker_list = document.getElementById('marker-list');
    localStorage.removeItem('markers');
    localStorage.removeItem('home');
    marker_list.innerHTML = '';
    markers=[];
    homeMarker = null;
    currentMarker = null;
}